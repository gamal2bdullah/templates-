// =======================================================================
//  LocaleContext — single source of truth for language + theme
//  Apply to <html dir="..."> + <html data-theme="..."> for full RTL/LTR + theme
// =======================================================================

import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { loadLocale, saveLocale, isRTL, type LocaleState, type Language, type ThemeMode } from './types';
import { t as translate } from './dict';

interface LocaleContextValue extends LocaleState {
  setLanguage: (l: Language) => void;
  setTheme: (t: ThemeMode) => void;
  setCustomAccent: (c: string) => void;
  t: (key: string) => string;
  dir: 'rtl' | 'ltr';
}

const LocaleContext = createContext<LocaleContextValue | null>(null);

export function LocaleProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<LocaleState>(() => loadLocale());

  useEffect(() => {
    saveLocale(state);
    // Apply to <html>
    const html = document.documentElement;
    html.setAttribute('lang', state.language);
    html.setAttribute('dir', isRTL(state.language) ? 'rtl' : 'ltr');
    html.setAttribute('data-theme', state.theme);
    if (state.theme === 'custom') {
      html.style.setProperty('--accent-custom', state.customAccent);
    }
  }, [state]);

  const setLanguage = (language: Language) => setState(s => ({ ...s, language }));
  const setTheme = (theme: ThemeMode) => setState(s => ({ ...s, theme }));
  const setCustomAccent = (customAccent: string) => setState(s => ({ ...s, customAccent }));
  const t = (key: string) => translate(state.language, key);
  const dir = isRTL(state.language) ? 'rtl' : 'ltr';

  return (
    <LocaleContext.Provider value={{ ...state, setLanguage, setTheme, setCustomAccent, t, dir }}>
      {children}
    </LocaleContext.Provider>
  );
}

export function useLocale() {
  const ctx = useContext(LocaleContext);
  if (!ctx) throw new Error('useLocale must be used within LocaleProvider');
  return ctx;
}
