// =======================================================================
//  Internationalization (i18n) + Theme System
//  - Default language: Arabic (RTL)
//  - Secondary: English (LTR)
//  - 3 themes: Light (default), Dark, Custom
//  - All keys structured by domain
// =======================================================================

export type Language = 'ar' | 'en';
export type ThemeMode = 'light' | 'dark' | 'custom';

export interface LocaleState {
  language: Language;
  theme: ThemeMode;
  customAccent: string; // hex color for Custom theme
}

// Storage
const LOCALE_KEY = 'kad-locale-v1';

export function loadLocale(): LocaleState {
  try {
    const raw = localStorage.getItem(LOCALE_KEY);
    if (raw) return { ...defaultLocale, ...JSON.parse(raw) };
  } catch {}
  return { ...defaultLocale };
}

export const defaultLocale: LocaleState = {
  language: 'ar',
  theme: 'light',
  customAccent: '#f59e0b',
};

export function saveLocale(state: LocaleState) {
  try { localStorage.setItem(LOCALE_KEY, JSON.stringify(state)); } catch {}
}

// Helpers
export const isRTL = (lang: Language) => lang === 'ar';
