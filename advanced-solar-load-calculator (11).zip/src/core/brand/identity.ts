// =======================================================================
//  KAD POWER — Visual Identity System
//  Source: KAD-Power-Logo-System.zip (Sections 3, 4, 5)
//
//  TWO PRIMARY ANCHORS:
//    1. NAVY (#1A2B6B)   — structural, brand mark, dark text
//    2. SOLAR GREEN (#99F36C) — accent, energy, activity
//
//  USAGE RATIO: 60% neutral / 30% navy / 10% green
//  WCAG AA: 17.29:1 (white on Navy 900) · 12.68:1 (green on Navy 900)
// =======================================================================

export const BRAND = {
  name: { en: 'KAD POWER', ar: 'كاد باور' },
  short: 'KAD',
  tagline: {
    en: 'Engineering-Grade Power Analysis',
    ar: 'تحليل هندسي متقدم لأنظمة الطاقة',
  },
  description: {
    en: 'Professional load analysis, validation, and reporting for solar and power systems engineering',
    ar: 'تحليل الأحمال والتحقق وإعداد التقارير الاحترافية لأنظمة الطاقة الشمسية والكهربائية',
  },
} as const;

// =======================================================================
//  OFFICIAL COLOR PALETTE — KAD POWER (extracted from archive)
// =======================================================================
export const PALETTE = {
  // === PRIMARY: NAVY (Structural) ===
  navy50:  '#F4F4F8',
  navy100: '#E4E6ED',
  navy200: '#C3C8D9',
  navy300: '#9FA6C1',
  navy400: '#5F6B97',
  navy500: '#1A2B6B', // ★ PRIMARY ANCHOR
  navy600: '#18275F',
  navy700: '#162251',
  navy800: '#131E43',
  navy900: '#111935', // ★ DEEPEST (text on light)

  // === ACCENT: SOLAR GREEN (Energy) ===
  green50:  '#FAFEF8',
  green100: '#F3FEED',
  green200: '#E4FCD9',
  green300: '#D4FAC1',
  green400: '#B8F798',
  green500: '#99F36C', // ★ PRIMARY ACCENT
  green600: '#85D360',
  green700: '#6EAE52',
  green800: '#588A44',
  green900: '#416535',

  // === SLATE NEUTRAL (Navy-tempered, H=227, S=16%) ===
  slate0:   '#FFFFFF',
  slate50:  '#F6F7F9',
  slate100: '#EAEBF0',
  slate200: '#D6D8E1',
  slate300: '#B8BCCC',
  slate400: '#8F95AE',
  slate500: '#6B7494',
  slate600: '#565D76',
  slate700: '#404559',
  slate800: '#2D313E',
  slate900: '#1E2029',
  slate950: '#111318',

  // === SEMANTIC (utility) ===
  white: '#FFFFFF',
  black: '#000000',
  danger: '#ef4444',
  warning: '#f59e0b',
} as const;

// =======================================================================
//  OFFICIAL GRADIENTS (from archive)
// =======================================================================
export const GRADIENTS = {
  /** Energy: Navy 500 → Solar Green 500 — strongest brand gradient */
  energy: `linear-gradient(135deg, ${PALETTE.navy500} 0%, ${PALETTE.green500} 100%)`,
  /** Depth: Navy 900 → Navy 500 */
  depth:  `linear-gradient(180deg, ${PALETTE.navy900} 0%, ${PALETTE.navy500} 100%)`,
  /** Glow: Green 300 → Green 600 */
  glow:   `linear-gradient(135deg, ${PALETTE.green300} 0%, ${PALETTE.green600} 100%)`,
  /** Dusk: Navy 800 → #3D2B6B */
  dusk:   `linear-gradient(135deg, ${PALETTE.navy800} 0%, #3D2B6B 100%)`,
} as const;

// =======================================================================
//  WCAG CONTRAST PAIRS (confirmed by archive)
// =======================================================================
export const CONTRAST_PAIRS = {
  whiteOnNavy900: 17.29,    // AA pass
  green500OnNavy900: 12.68, // AA pass
  navy900OnWhite: 17.29,    // AA pass
  navy900OnGreen500: 12.68, // AA pass
  whiteOnBlack: 19.32,      // AA pass
} as const;
