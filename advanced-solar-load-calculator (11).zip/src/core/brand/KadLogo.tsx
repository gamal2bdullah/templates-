// =======================================================================
//  KAD POWER — Official Logo Component
//  Uses the EXACT official icon (electricity pylon/grid tower with KAD lettering)
//  Colors: Navy 500 (#1A2B6B) and Solar Green 500 (#99F36C)
//
//  The official logo combines:
//   - A stylized electricity pylon (transmission tower) outline
//   - The "KAD POWER" wordmark integrated as 3D structural drawing
//   - Navy structural color + Solar Green energy accents
// =======================================================================

import type { CSSProperties } from 'react';

interface KadLogoProps {
  size?: number;
  showText?: boolean;
  variant?: 'full' | 'mark' | 'text';
  className?: string;
  style?: CSSProperties;
  /** Override the default green accent color (Solar Green 500) */
  accentColor?: string;
  /** Override the default navy color (Navy 500) */
  primaryColor?: string;
  textColor?: string;
}

// =======================================================================
//  OFFICIAL KAD POWER SVG ICON
//  Renders the exact pylon + wordmark from the brand archive
// =======================================================================
const OFFICIAL_KAD_ICON_SVG = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150">
  <path
    fill="#99F36C"
    d="m124.9 54.9-12.3-8.1c-1.1-0.5-2.1-0.6-2.1 1.2-0.1 1.9-0.1 7.4 0.1 8.5 0.3 1.3 5.6 3.3 7.5 4.7 1.5 1 2.3 2.5 2.3 4.7l0.3 47.1c0 1.4-0.7 2.5-1.8 3.2l-41 23.1c-1.5 0.8-2.9 1-4.6 0.2-3.8-1.8-32.8-17.6-40.8-21.9-2.9-1.6-3-3.3-3-5.8l-0.4-45.7c0-1.7 0.6-3 2.3-4l6.7-3.9c0.8-0.6 0.8-0.6 0.8-1.6 0.1-2.3 0-4.8 0-7.1 0.1-1.4 0-2.2-1.3-2.4-2.1 1-8.9 5-12.1 7-2.4 1.4-4.1 3.5-4.7 6l-1 3.6 0.5 50.5c0.1 4 1.7 7.9 4.9 9.9l14.8 7.9c9.6 5.4 19.5 10.4 29.6 16.1 1.3 0.7 2.7 1.3 3.8 1.7h3.8c3.2-0.9 6.7-2.9 10-4.8 9-5.4 20.7-11.3 31.2-17.4 2.3-1.3 4.7-2.6 6.6-3.9 2.4-1.6 4.2-4.3 4.8-7.7l0.3-0.5c0.1-15.6-0.3-33.3-0.3-51.6-0.2-3.9-1.8-7.2-4.9-9z"
  />
  <path
    fill="#99F36C"
    d="m47.9 47c0 0.4 0.5 0.5 1.7 0.7 2 0.2 2.9 1.4 2.9 3.5v7.5c1.1-0.8 5.7-6.2 7.6-8.6 1.6-2.1 2.8-2.7 4.3-2.7l29.2 0.1c0.6-0.6-0.6-0.6-1.6-1.1l-11.2-3.3c0 0.6-0.2 2-0.3 2h-5.1c-1.2 0-1.3-0.5-1.3-1.7v-16.2c0-1.1 1-1.1 3.5-2.3 1.3-0.4 1.1-1.5 1.1-3.3-0.1-1.9 0.2-4.6-0.2-5.2-0.4-0.7-2.1-1.4-5.1-3.5-1.2-0.7-1.5-0.5-2-0.3l-8.4 4.5c-1.1 0.5-1.5 1.4-1.2 2.4v6.4h1.7c0.1 0 0-3 0-3-0.5-3.4 0.4-5 3.5-5.9l3.5-2.1h0.1v30.2h-5c-0.6 0-0.7-0.6-0.7-0.7v-11.4c0-1.3 1-1.9 1.7-2.6l1.8-1.8-0.2-0.4c-2.7 0.2-3.2-0.2-5.1 0.2-1.6 0.1-2.7 1-4 2.5-0.7 0.8-0.6 1.6-0.6 3.1v11.4c0 0.6-0.3 0.7-0.9 0.7-2.4 0-9.7 0.8-9.7 0.9z"
  />
  <path
    fill="#99F36C"
    d="m68.1 12.1 4.5-2.1c1-0.3 1.4-1.1 1.4-1.9v-5c0-0.4 0.5-0.1 0.9 0l6.6 3.9c0.6 0.5 0.7 0.9 0.7 1.6l0.2 5.9v7.6c0 1.4 0.7 1.4 1.5 1.4l-0.1-15.5c0.1-1-0.3-1.3-1.1-1.9l-9.1-5c-1.1-0.7-1.2-0.6-2.2 0.1l-1.8 1.2c-1.2 1.1-1.6 2.1-1.5 3.6 0.3 2.5 0 6.1 0 6.1z"
  />
  <path fill="#99F36C" d="m91.4 27.9-10.6-4.2-0.1 2.7 10.7 4v-2.5z" />
  <path fill="#99F36C" d="m91.4 32.4-10.7-4.2v2.5l10.7 4.2v-2.5z" />
  <path fill="#99F36C" d="m91.4 36.4-10.6-4.2v2.5l10.6 3.9v-2.2z" />
  <path fill="#99F36C" d="m91.4 40-10.6-3.9v2.4l10.6 4.1v-2.6z" />
  <path fill="#99F36C" d="m91.4 43.5-10.6-3.9v2.4l10.6 3.6v-2.1z" />
  <path
    fill="#99F36C"
    d="m91.4 50h-14.7l2.8 4c0.9 1.7 1.9 2.4 4.4 2.4 3.5-0.2 8.5-0.2 11.2 0.2 4 0.5 8.3 3.9 8.3 9.5 0 7.4-6.4 10.3-9.8 10.4-1 0-1.7-0.4-2.4-1.5l-17.3-24.5c-0.8-1-0.9-1-2-1h-8.5c-0.8 0-1 0.1-1.4 0.6l-10.9 13.3h-0.5v-8.8c0-4.1 0.1-4.6-3-4.6h-3.5v30.2l0.4 0.1 8.5-9.3 6 8.2c2.5 3.2 2.1 3.3 4.6 3.3h5.5l-11.2-15.6c-0.7-1-0.3-1.4 0.1-1.9l9.9-11.5c2.8 4.1 5.3 6 5.3 9-0.1 1.9-1.5 4-4.7 4h-4.6v4.1h15.2c0.9 0 0.9-0.1 1.9 1.1l6.5 8.9c1.1 1.4 1.5 1.8 4.2 1.9 10.5 0.5 17.5-6 18-15 0.4-6.6-4.1-17.5-18.3-17.5z"
  />
  <path
    fill="#1A2B6B"
    d="m117.2 88.7-42 1.2c-0.8 0-1.1-0.8-1.3-5.2l-40.8 14.5c-0.7 0.3-1.1 0.7-1 1.9v10.4c0.1 2.4 1.1 3.5 2.4 4l2.1 1.1c0.9 0.4 1.8 0.4 2.5 0.3l16.5-3.4c1.3-0.3 2-1.3 1.8-2.6l-5-11.7c-0.2-0.7 0-1.6 0.1-1.5l1.2 0.5 3.8 8.5c0.9 2.8 2.1 4.8 4.6 5.3l15-3.5c0.9-0.1 1.1-1.4 0.8-2.3l-2.3-6.2c0.5-0.4 1.3-0.5 1.5 0l1.9 4.5c0.6 1.4 1.4 1.7 2 1.9 0.5 0.2 0.5 0.6 1.2 0.6l13.4-2.9c1.3-0.2 1-1.2 0.8-1.7l-3-7.4c0.5-0.3 1.2-0.1 1.5 0l3 6.4c1 1.7 2.3 1.8 3.7 1.5l8.3-1.9c1.3-0.3 1.3-1.1 0.7-2.6-2-4.3-3.4-7.2-3.1-7.2h1c0.5 0 0.5 0.2 0.9 0.8l2.7 6.1c0.8 1.5 2.3 2.3 4.5 1.3 0.8-0.3 0.9-0.9 0.9-2v-8.7h-0.3z"
  />
  <path
    fill="#99F36C"
    d="m42.7 97.2c0.2-0.6 15.9-5.6 29.9-10.7l0.8 4.6 31.5-0.7v0.3l-34.3 9.2-0.6-5.4c-0.6 0-23.5 2.5-27.3 2.7z"
  />
  <path
    fill="#1A2B6B"
    d="m40.5 117.6c-0.8 0-1 0.8 0 1.1l22.5 12.3c2.1 1 2.7-0.6 2.5-2.1l-5.5-12.3c-0.6-1.1-2.1-2.2-3.4-2.2l-16.1 3.2z"
  />
  <path
    fill="#1A2B6B"
    d="m62.4 113.4c-1.4 0.2-1.9 1.2-0.9 3.3l5.4 11.7c0.6 1 2.6 1.2 3.5 1l13-4.5c1.1-0.4 2.1-1.3 1.7-2.7l-5.1-10.6c-0.6-1.2-1.9-2.1-3.3-1.9l-14.3 3.7z"
  />
  <path
    fill="#1A2B6B"
    d="m82.6 108.6c-0.9 0.4-1.2 1.3-1 2l5.3 11c0.5 1.1 2.1 1.4 3.2 1l11.9-4c0.7-0.2 1.1-1.6 0.6-2.5l-4.1-9.1c-0.9-1.5-2.1-1.8-4-1.3l-11.9 2.9z"
  />
  <path
    fill="#1A2B6B"
    d="m100.6 104.5c-1 0.4-1.2 0.7-1 1.4l4.9 10.5c0.4 1 1.4 1.1 2.6 0.8l8.8-2.8c1-0.4 1.1-0.9 0.6-2l-3.5-8.3c-0.6-1.1-1.4-2.1-3-1.7l-9.4 2.1z"
  />
  <path
    fill="#1A2B6B"
    d="m114.4 102.5 3.1 8.7v-10.7l-2.9 0.5c-0.7 0.4-0.7 1-0.2 1.5z"
  />
  <path
    fill="#1A2B6B"
    d="m69.9 130.9c-0.9 0.5-1.2 2.8 0 4 1.2 0.7 3.7 2.2 5.1 2.2 0.9 0 2-0.5 2.6-0.9l10-5.6c0.9-0.6 0.9-1 0.8-1.4l-0.8-1.8c-0.7-1.2-2.7-1.8-3.4-1.7l-13.6 4.8-0.7 0.4z"
  />
  <path
    fill="#1A2B6B"
    d="m89.9 129 14.7-8.4c-0.7-1-1.7-1-2.7-0.6l-10.5 3.4c-1.8 0.7-3.2 1.6-2.3 3.5l0.8 2.1z"
  />
  <path fill="#1A2B6B" d="m106.1 119.6 2.9-1.5c-1.4 0-2.5 0.5-2.9 1.5z" />
  <path
    fill="#1A2B6B"
    d="m102.5 33.4c-2.3 0.1-4.5 2.1-4.5 4.2 0 2.5 2 4.4 4.4 4.3 2.2 0 4.3-1.8 4.3-4.2 0-2.3-2-4.3-4.2-4.3zm-0.1 8c-2 0-3.8-1.7-3.8-3.8 0-2 1.8-3.7 3.9-3.7 2 0.1 3.7 1.7 3.7 3.7s-1.7 3.8-3.8 3.8z"
  />
  <path
    fill="#99F36C"
    d="m102.5 34.2c-1.9 0-3.6 1.5-3.6 3.4s1.6 3.5 3.5 3.5c2 0 3.6-1.5 3.6-3.5 0-1.7-1.6-3.4-3.5-3.4z"
  />
  <path
    fill="#1A2B6B"
    d="m103.4 37.7c0.5-0.1 0.8-0.5 0.8-1.1 0-0.4-0.2-0.7-0.5-1-0.2-0.1-0.6-0.2-1.1-0.2-0.4 0-0.9 0-1.4 0.1v4.4h0.5v-1.9h0.7c0.6 0.1 0.8 0.4 1 1 0.1 0.6 0.2 1 0.3 1.1h0.7c-0.2-0.2-0.3-0.6-0.4-1.2-0.1-0.7-0.4-1-0.6-1.2zm-1-0.2h-0.7v-1.8h0.7c0.7 0 1.2 0.3 1.2 0.9 0 0.5-0.5 0.9-1.2 0.9z"
  />
</svg>
`.trim();

// =======================================================================
//  OFFICIAL LOGO COMPONENT
// =======================================================================
export function KadLogo({
  size = 40,
  showText = true,
  variant = 'full',
  className,
  style,
  textColor,
}: KadLogoProps) {
  const color = textColor || 'currentColor';
  const markSize = size;

  if (variant === 'mark') {
    return (
      <span
        className={className}
        style={{ display: 'inline-block', width: markSize, height: markSize, ...style }}
        role="img"
        aria-label="KAD POWER"
        dangerouslySetInnerHTML={{ __html: OFFICIAL_KAD_ICON_SVG.replace('<svg ', `<svg width="${markSize}" height="${markSize}" `) }}
      />
    );
  }

  if (variant === 'text') {
    return (
      <span className={className} style={{ fontWeight: 800, fontSize: size * 0.5, letterSpacing: '0.05em', color, ...style }}>
        KAD<span style={{ color: '#99F36C' }}>·</span>POWER
      </span>
    );
  }

  // Full: mark + text
  return (
    <div className={className} style={{ display: 'inline-flex', alignItems: 'center', gap: size * 0.25, ...style }}>
      <KadLogo size={markSize} variant="mark" />
      {showText && (
        <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.1 }}>
          <span style={{ fontWeight: 800, fontSize: size * 0.42, letterSpacing: '0.05em', color }}>
            KAD<span style={{ color: '#99F36C' }}>·</span>POWER
          </span>
          <span style={{
            fontSize: size * 0.2,
            fontWeight: 500,
            letterSpacing: '0.15em',
            opacity: 0.65,
            color,
            textTransform: 'uppercase',
          }}>
            Engineering Analysis Suite
          </span>
        </div>
      )}
    </div>
  );
}

export function KadLogoMark({ size = 36 }: { size?: number }) {
  return <KadLogo size={size} variant="mark" />;
}
