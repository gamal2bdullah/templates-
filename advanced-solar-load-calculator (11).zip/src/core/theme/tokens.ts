// =======================================================================
//  KAD POWER — Design Tokens
//  Light: Slate neutrals + Navy 500 structure + Solar Green 500 accent
//  Dark:  Navy 900 base + Slate neutrals + Solar Green 500 accent
//  Custom: Dusk-inspired (Navy 800 → #3D2B6B) with Solar Green 500
// =======================================================================

import { PALETTE } from '../brand/identity';

export const tokens = {
  light: {
    // Surfaces — 60% neutral backgrounds (Slate family)
    '--bg':         PALETTE.slate50,    // #F6F7F9
    '--bg-2':       PALETTE.white,      // #FFFFFF
    '--panel':      PALETTE.white,
    '--panel-2':    PALETTE.slate100,   // #EAEBF0
    '--border':     PALETTE.slate200,   // #D6D8E1
    '--border-2':   PALETTE.slate300,   // #B8BCCC

    // Text — Navy for max contrast (17.29:1)
    '--text':       PALETTE.navy900,    // #111935
    '--text-2':     PALETTE.slate700,   // #404559
    '--text-3':     PALETTE.slate500,   // #6B7494

    // Brand — 30% Navy + 10% Green
    '--accent':     PALETTE.navy500,    // #1A2B6B — PRIMARY ANCHOR
    '--accent-2':   PALETTE.green500,   // #99F36C — ACCENT
    '--brand':      PALETTE.navy500,
    '--solar':      PALETTE.green500,
    '--success':    PALETTE.green600,   // #85D360
    '--warning':    '#f59e0b',
    '--danger':     '#ef4444',
    '--info':       PALETTE.navy400,    // #5F6B97

    '--grid-opacity': '0.06',
  },
  dark: {
    // Dark — Navy 900 base, Depth gradient anchor
    '--bg':         PALETTE.navy900,    // #111935 — deepest
    '--bg-2':       PALETTE.navy800,    // #131E43
    '--panel':      PALETTE.navy800,
    '--panel-2':    PALETTE.navy700,   // #162251
    '--border':     PALETTE.navy700,
    '--border-2':   PALETTE.navy600,   // #18275F

    '--text':       PALETTE.white,      // 17.29:1 on Navy 900
    '--text-2':     PALETTE.slate200,   // #D6D8E1
    '--text-3':     PALETTE.slate400,   // #8F95AE

    '--accent':     PALETTE.green500,   // #99F36C — pops on Navy
    '--accent-2':   PALETTE.green400,   // #B8F798
    '--brand':      PALETTE.navy300,    // #9FA6C1
    '--solar':      PALETTE.green500,
    '--success':    PALETTE.green400,
    '--warning':    '#f59e0b',
    '--danger':     '#ef4444',
    '--info':       PALETTE.green300,   // #D4FAC1

    '--grid-opacity': '0.04',
  },
  custom: {
    // Custom — Dusk-inspired purple-black with Solar Green
    '--bg':         '#0d0a1f',
    '--bg-2':       '#1a1233',
    '--panel':      '#1f1640',
    '--panel-2':    '#2a1d52',
    '--border':     '#3d2a6e',
    '--border-2':   '#4d3590',

    '--text':       PALETTE.slate50,
    '--text-2':     PALETTE.slate200,
    '--text-3':     PALETTE.slate400,

    '--accent':     'var(--accent-custom, #99F36C)',
    '--accent-2':   '#B8F798',
    '--brand':      '#99F36C',
    '--solar':      '#99F36C',
    '--success':    PALETTE.green500,
    '--warning':    '#f59e0b',
    '--danger':     '#ef4444',
    '--info':       PALETTE.green300,

    '--grid-opacity': '0.06',
  },
} as const;

export type ThemeKey = keyof typeof tokens;

export const themeCSS = `
[data-theme="light"] {
  ${Object.entries(tokens.light).map(([k, v]) => `${k}: ${v};`).join('\n  ')}
  color-scheme: light;
}
[data-theme="dark"] {
  ${Object.entries(tokens.dark).map(([k, v]) => `${k}: ${v};`).join('\n  ')}
  color-scheme: dark;
}
[data-theme="custom"] {
  ${Object.entries(tokens.custom).map(([k, v]) => `${k}: ${v};`).join('\n  ')}
  color-scheme: dark;
}
`;
