// Tailwind class safelist — these are referenced dynamically in code via templates
// Tailwind v4 only generates classes it finds literally in source files.
// This file ensures all dynamically-used color utilities are generated.

// Import this from somewhere to ensure the classes appear in source
export const SAFELIST_COLORS: string[] = [
  // Text colors
  'text-orange-300', 'text-orange-400', 'text-orange-500',
  'text-amber-300', 'text-amber-400', 'text-amber-500',
  'text-emerald-300', 'text-emerald-400', 'text-emerald-500',
  'text-blue-300', 'text-blue-400', 'text-blue-500', 'text-blue-600',
  'text-red-300', 'text-red-400', 'text-red-500',
  'text-pink-300', 'text-pink-400', 'text-pink-500',
  'text-violet-300', 'text-violet-400', 'text-violet-500',
  'text-cyan-300', 'text-cyan-400', 'text-cyan-500',
  'text-purple-300', 'text-purple-400', 'text-purple-500',
  'text-indigo-300', 'text-indigo-400', 'text-indigo-500',
  'text-yellow-300', 'text-yellow-400', 'text-yellow-500',
  'text-rose-300', 'text-rose-400', 'text-rose-500',
  'text-sky-300', 'text-sky-400', 'text-sky-500',
  'text-fuchsia-300', 'text-fuchsia-400', 'text-fuchsia-500',
  'text-teal-300', 'text-teal-400', 'text-teal-500',
  'text-slate-300', 'text-slate-400', 'text-slate-500', 'text-slate-800', 'text-slate-900',
  'text-amber-200', 'text-red-200', 'text-emerald-200', 'text-cyan-200', 'text-orange-200', 'text-indigo-200',
  'text-pink-200', 'text-violet-200', 'text-sky-200', 'text-fuchsia-200',
  'text-emerald-300/80', 'text-amber-300/80', 'text-red-300/80',
  'text-amber-300/80', 'text-emerald-300/80',

  // Background colors
  'bg-orange-500/10', 'bg-orange-500/15', 'bg-orange-500/20', 'bg-orange-500/30', 'bg-orange-500/40',
  'bg-amber-500/10', 'bg-amber-500/15', 'bg-amber-500/20', 'bg-amber-500/30', 'bg-amber-500/40',
  'bg-emerald-500/10', 'bg-emerald-500/15', 'bg-emerald-500/20', 'bg-emerald-500/30', 'bg-emerald-500/40',
  'bg-blue-500/10', 'bg-blue-500/15', 'bg-blue-500/20', 'bg-blue-500/30',
  'bg-red-500/10', 'bg-red-500/15', 'bg-red-500/20', 'bg-red-500/30', 'bg-red-500/40',
  'bg-pink-500/10', 'bg-pink-500/15', 'bg-pink-500/20', 'bg-pink-500/30', 'bg-pink-500/40',
  'bg-violet-500/10', 'bg-violet-500/15', 'bg-violet-500/20', 'bg-violet-500/30', 'bg-violet-500/40',
  'bg-cyan-500/10', 'bg-cyan-500/15', 'bg-cyan-500/20', 'bg-cyan-500/30',
  'bg-purple-500/10', 'bg-purple-500/20', 'bg-purple-500/30',
  'bg-indigo-500/10', 'bg-indigo-500/20', 'bg-indigo-500/30',
  'bg-yellow-500/10', 'bg-yellow-500/20', 'bg-yellow-500/30',
  'bg-rose-500/10', 'bg-rose-500/20', 'bg-rose-500/30',
  'bg-sky-500/10', 'bg-sky-500/20', 'bg-sky-500/30',
  'bg-fuchsia-500/10', 'bg-fuchsia-500/20', 'bg-fuchsia-500/30',
  'bg-slate-500/10', 'bg-slate-500/20', 'bg-slate-500/30', 'bg-slate-500/40',
  'bg-slate-800', 'bg-slate-800/30', 'bg-slate-800/40', 'bg-slate-800/50', 'bg-slate-800/60', 'bg-slate-800/80',
  'bg-slate-900', 'bg-slate-900/30', 'bg-slate-900/40', 'bg-slate-900/50', 'bg-slate-900/70', 'bg-slate-900/80', 'bg-slate-900/95',
  'bg-slate-700', 'bg-slate-700/30', 'bg-slate-700/40', 'bg-slate-700/50', 'bg-slate-700/60',
  'bg-slate-950/40',
  'bg-white', 'bg-black/60',

  // Borders
  'border-orange-500/20', 'border-orange-500/30', 'border-orange-500/40', 'border-orange-500/50', 'border-orange-500/60',
  'border-amber-500/20', 'border-amber-500/30', 'border-amber-500/40', 'border-amber-500/50',
  'border-emerald-500/20', 'border-emerald-500/30', 'border-emerald-500/40', 'border-emerald-500/50',
  'border-blue-500/20', 'border-blue-500/30', 'border-blue-500/40',
  'border-red-500/20', 'border-red-500/30', 'border-red-500/40', 'border-red-500/50',
  'border-pink-500/20', 'border-pink-500/30', 'border-pink-500/40',
  'border-violet-500/20', 'border-violet-500/30', 'border-violet-500/40',
  'border-cyan-500/20', 'border-cyan-500/30',
  'border-purple-500/30', 'border-purple-500/40',
  'border-indigo-500/20', 'border-indigo-500/30',
  'border-yellow-500/20', 'border-yellow-500/30',
  'border-rose-500/20', 'border-rose-500/30',
  'border-sky-500/20', 'border-sky-500/30',
  'border-fuchsia-500/20', 'border-fuchsia-500/30',
  'border-slate-500/30', 'border-slate-600/30',
  'border-slate-700', 'border-slate-700/50',
  'border-slate-800', 'border-slate-800/40', 'border-slate-800/50', 'border-slate-800/80',
  'border-white',

  // Fill colors
  'fill-orange-500', 'fill-amber-500', 'fill-emerald-500', 'fill-blue-500',
  'fill-pink-500', 'fill-violet-500', 'fill-cyan-500', 'fill-purple-500',
  'fill-indigo-500', 'fill-yellow-500', 'fill-rose-500', 'fill-sky-500',
  'fill-fuchsia-500', 'fill-slate-500', 'fill-slate-800', 'fill-slate-700',
  'fill-red-500', 'fill-teal-500',

  // Stroke
  'stroke-orange-500', 'stroke-amber-500', 'stroke-emerald-500', 'stroke-blue-500',
  'stroke-pink-500', 'stroke-violet-500', 'stroke-cyan-500', 'stroke-red-500',
  'stroke-slate-700', 'stroke-slate-800',
];

export const SAFELIST_GRADIENTS: string[] = [
  'bg-gradient-to-r', 'bg-gradient-to-l', 'bg-gradient-to-br', 'bg-gradient-to-bl', 'bg-gradient-to-tl', 'bg-gradient-to-tr',
  'from-orange-500', 'from-amber-500', 'from-amber-400', 'from-emerald-500', 'from-blue-500', 'from-blue-600',
  'from-pink-500', 'from-violet-500', 'from-cyan-500', 'from-red-500', 'from-red-400',
  'from-indigo-500', 'from-yellow-500', 'from-rose-500', 'from-sky-500',
  'from-fuchsia-500', 'from-teal-500', 'from-slate-500', 'from-slate-700', 'from-slate-800', 'from-slate-900',
  'to-orange-500', 'to-amber-500', 'to-amber-400', 'to-emerald-500', 'to-blue-500', 'to-blue-600',
  'to-pink-500', 'to-violet-500', 'to-cyan-500', 'to-red-500', 'to-red-400',
  'to-indigo-500', 'to-indigo-600', 'to-yellow-500', 'to-rose-500', 'to-sky-500',
  'to-fuchsia-500', 'to-teal-500', 'to-slate-500', 'to-slate-800', 'to-slate-900',
];
