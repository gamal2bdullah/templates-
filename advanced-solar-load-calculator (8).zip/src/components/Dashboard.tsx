import { useLoads, useSummary, useLoadMetrics } from '../context/LoadContext';
import { fmtW, fmtWh, fmtA, fmtKVA, fmtPct } from '../utils/calculations';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { Zap, Sun, Battery, TrendingUp, AlertTriangle, Activity, Sparkles, ArrowRight, CheckCircle2, Gauge } from 'lucide-react';
import type { ViewKey } from '../App';

export function Dashboard({ onNavigate }: { onNavigate: (v: ViewKey) => void }) {
  const { loads, projectName, expertLevel } = useLoads();
  const summary = useSummary();
  const metrics = useLoadMetrics();

  const hourlyData = summary.hourlyProfile.map((v, i) => ({
    hour: `${i}:00`,
    power: Math.round(v / 1000 * 10) / 10, // kW
    day: i >= 8 && i < 18 ? Math.round(v / 1000 * 10) / 10 : 0,
    night: (i < 8 || i >= 18) ? Math.round(v / 1000 * 10) / 10 : 0,
  }));

  const peakHour = summary.hourlyProfile.indexOf(Math.max(...summary.hourlyProfile));
  const peakPower = Math.max(...summary.hourlyProfile) / 1000;

  // Surge detection
  const highSurge = metrics.filter(m => m.surge > 2000).slice(0, 5);
  // Critical loads
  const critical = loads.filter(l => l.criticality === 'Critical').length;
  // Phantom
  const phantomLoads = loads.filter(l => l.phantomLoadW > 0).length;

  return (
    <div className="p-6 space-y-6 max-w-[1800px] mx-auto">
      {/* Hero / Project Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-slate-800/80 bg-gradient-to-br from-[#131a2e] via-[#0f1424] to-[#0a0e1a] p-6 solar-glow">
        <div className="absolute -right-20 -top-20 w-80 h-80 rounded-full bg-orange-500/10 blur-3xl" />
        <div className="absolute -left-20 -bottom-20 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl" />
        <div className="relative flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 text-orange-400 text-xs font-medium mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Itel Solar Engineering Suite · {expertLevel} Mode</span>
            </div>
            <h1 className="text-3xl font-bold text-white tracking-tight">{projectName}</h1>
            <p className="text-slate-400 mt-1 text-sm max-w-2xl">
              Advanced load analysis with time-based, hierarchical, scenario-driven multi-level engine.
              All calculations follow NEC/IEC industry practice.
            </p>
            <div className="flex flex-wrap gap-2 mt-4">
              <button onClick={() => onNavigate('inventory')} className="px-4 py-2 rounded-lg bg-gradient-to-r from-orange-500 to-amber-500 text-white text-sm font-semibold shadow-lg shadow-orange-500/30 hover:shadow-orange-500/50 transition flex items-center gap-2">
                <Zap className="w-4 h-4" /> Add Loads
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => onNavigate('analysis')} className="px-4 py-2 rounded-lg bg-slate-800/60 border border-slate-700 text-slate-200 text-sm font-medium hover:bg-slate-700/60 transition">
                View Analysis
              </button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 lg:w-96">
            <BigMetric label="Total Connected" value={fmtW(summary.totalConnectedLoadW, 1)} icon={Zap} color="orange" />
            <BigMetric label="Max Demand" value={fmtW(summary.maximumDemandW, 1)} icon={Gauge} color="amber" />
            <BigMetric label="Daily Energy" value={fmtWh(summary.totalDailyEnergyWh, 1)} icon={Sun} color="emerald" />
            <BigMetric label="Annual" value={fmtWh(summary.annualEnergyKWh * 1000, 1)} icon={Battery} color="blue" />
          </div>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <KPI label="Peak Demand" value={fmtW(summary.peakDemandKW * 1000, 1)} sub="Maximum simultaneous" color="orange" icon={TrendingUp} />
        <KPI label="Peak kVA" value={fmtKVA(summary.peakDemandKVA)} sub="Apparent power" color="amber" icon={Activity} />
        <KPI label="Max Current" value={fmtA(summary.estimatedMaxCurrentA)} sub="Per phase" color="red" icon={Zap} />
        <KPI label="Max Surge" value={fmtW(summary.maximumSurgeKW * 1000, 1)} sub="Total starting" color="pink" icon={AlertTriangle} />
        <KPI label="Load Factor" value={fmtPct(summary.loadFactor)} sub="Avg/Peak ratio" color="cyan" icon={Gauge} />
        <KPI label="Loads" value={loads.length.toString()} sub={`${critical} critical`} color="purple" icon={CheckCircle2} />
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* 24h Load Profile */}
        <div className="xl:col-span-2 rounded-xl border border-slate-800/80 bg-[#0f1424] p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">24-Hour Load Profile</h3>
              <p className="text-xs text-slate-500">Aggregated operating load by hour · Peak at {peakHour}:00 → {peakPower.toFixed(2)} kW</p>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="px-2 py-1 rounded bg-orange-500/15 text-orange-300 border border-orange-500/20 font-mono">
                Peak {peakPower.toFixed(1)} kW
              </span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={hourlyData}>
              <defs>
                <linearGradient id="gradOrange" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ff6a00" stopOpacity={0.7} />
                  <stop offset="95%" stopColor="#ff6a00" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gradAmber" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#fbbf24" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#fbbf24" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="#1f2a44" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="hour" stroke="#6b7a9c" fontSize={10} tickLine={false} axisLine={false} interval={2} />
              <YAxis stroke="#6b7a9c" fontSize={10} tickLine={false} axisLine={false} unit=" kW" />
              <Tooltip
                contentStyle={{ background: '#0f1424', border: '1px solid #2a3656', borderRadius: 8 }}
                labelStyle={{ color: '#a3b1d1' }}
                itemStyle={{ color: '#ffb547' }}
                formatter={(v: any) => `${v.toFixed(2)} kW`}
              />
              <Area type="monotone" dataKey="power" stroke="#ff6a00" strokeWidth={2.5} fill="url(#gradOrange)" />
              <Area type="monotone" dataKey="day" stackId="a" stroke="#fbbf24" fill="url(#gradAmber)" />
              <Area type="monotone" dataKey="night" stackId="a" stroke="#3b82f6" fill="url(#gradAmber)" fillOpacity={0.05} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Category breakdown */}
        <div className="rounded-xl border border-slate-800/80 bg-[#0f1424] p-5">
          <h3 className="text-sm font-semibold text-white mb-1">Load Distribution</h3>
          <p className="text-xs text-slate-500 mb-4">By category — daily energy share</p>
          {summary.byCategory.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={summary.byCategory} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90} paddingAngle={2}>
                  {summary.byCategory.map((d, i) => <Cell key={i} fill={d.color} />)}
                </Pie>
                <Tooltip
                  contentStyle={{ background: '#0f1424', border: '1px solid #2a3656', borderRadius: 8 }}
                  formatter={(v: any) => fmtWh(v as number, 1)}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: 10, color: '#a3b1d1' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-60 flex items-center justify-center text-slate-500 text-sm">No data yet</div>
          )}
        </div>
      </div>

      {/* Second row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Day vs Night */}
        <div className="rounded-xl border border-slate-800/80 bg-[#0f1424] p-5">
          <div className="flex items-center gap-2 mb-3">
            <Sun className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">Day / Night Energy</h3>
          </div>
          <div className="space-y-3">
            <BarRow label="Day Energy" value={summary.dayEnergyWh} total={summary.totalDailyEnergyWh} color="from-amber-500 to-orange-500" />
            <BarRow label="Night Energy" value={summary.nightEnergyWh} total={summary.totalDailyEnergyWh} color="from-indigo-500 to-blue-600" />
            <BarRow label="Critical Loads" value={summary.criticalLoadWh} total={summary.totalDailyEnergyWh} color="from-red-500 to-pink-500" />
            <BarRow label="Deferrable" value={summary.deferrableLoadWh} total={summary.totalDailyEnergyWh} color="from-emerald-500 to-teal-500" />
            <BarRow label="Phantom" value={summary.phantomLossWh} total={summary.totalDailyEnergyWh} color="from-purple-500 to-violet-500" />
          </div>
        </div>

        {/* Critical Insights */}
        <div className="rounded-xl border border-slate-800/80 bg-[#0f1424] p-5">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-4 h-4 text-orange-400" />
            <h3 className="text-sm font-semibold text-white">Engineering Insights</h3>
          </div>
          <div className="space-y-2.5">
            <Insight
              ok={summary.peakDemandKW < 50}
              text={summary.peakDemandKW < 50 ? 'Peak demand within residential scale' : 'Peak demand indicates commercial sizing'}
              sub={`${summary.peakDemandKW.toFixed(2)} kW peak`}
            />
            <Insight
              ok={summary.maximumSurgeKW < summary.peakDemandKW * 8}
              text={summary.maximumSurgeKW < summary.peakDemandKW * 8 ? 'Surge within design tolerance' : 'High inrush — oversize inverter'}
              sub={`${summary.maximumSurgeKW.toFixed(1)} kW max surge`}
            />
            <Insight
              ok={summary.loadFactor > 25}
              text={summary.loadFactor > 25 ? 'Healthy load factor — efficient utilization' : 'Low load factor — heavy peaks vs average'}
              sub={`${summary.loadFactor.toFixed(1)}% load factor`}
            />
            <Insight
              ok={phantomLoads < 6}
              text={phantomLoads === 0 ? 'No phantom loads detected' : `${phantomLoads} phantom loads — ${(summary.phantomLossWh/1000).toFixed(1)} kWh/day wasted`}
              sub="Standby consumption check"
            />
            <Insight
              ok={highSurge.length < 4}
              text={highSurge.length === 0 ? 'No large surge loads' : `${highSurge.length} high-surge loads require soft-start`}
              sub="Motor starting analysis"
            />
          </div>
        </div>

        {/* Top loads */}
        <div className="rounded-xl border border-slate-800/80 bg-[#0f1424] p-5">
          <h3 className="text-sm font-semibold text-white mb-3">Top Loads by Energy</h3>
          <div className="space-y-2 max-h-72 overflow-y-auto">
            {[...metrics].sort((a, b) => b.daily - a.daily).slice(0, 8).map(m => (
              <div key={m.load.id} className="flex items-center gap-3 text-xs">
                <div className="flex-1 min-w-0">
                  <div className="text-slate-200 truncate">{m.load.loadName || m.load.arabicName || '(unnamed)'}</div>
                  <div className="text-slate-500 text-[10px]">{m.load.categoryMain} · ×{m.load.quantity}</div>
                </div>
                <div className="text-right shrink-0">
                  <div className="font-mono text-orange-300 font-semibold">{fmtWh(m.daily, 0)}</div>
                  <div className="text-[10px] text-slate-500">{fmtW(m.connected, 0)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stage cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
        <StageCard num="01" title="Connected Load" value={fmtW(summary.totalConnectedLoadW, 1)} sub="Sum of nameplate × qty" />
        <StageCard num="02" title="Maximum Demand" value={fmtW(summary.maximumDemandW, 1)} sub="Peak operating load" />
        <StageCard num="03" title="Daily Energy" value={fmtWh(summary.totalDailyEnergyWh, 1)} sub="24h consumption" />
        <StageCard num="04" title="Annual Energy" value={fmtWh(summary.annualEnergyKWh * 1000, 1)} sub="Yearly consumption" />
      </div>
    </div>
  );
}

function BigMetric({ label, value, icon: Icon, color }: any) {
  return (
    <div className="rounded-lg bg-slate-900/40 border border-slate-800 p-3">
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-slate-400 font-medium">
        <Icon className={`w-3 h-3 text-${color}-400`} />
        {label}
      </div>
      <div className={`text-lg font-bold mono text-${color}-300 mt-1`}>{value}</div>
    </div>
  );
}

function KPI({ label, value, sub, color, icon: Icon }: any) {
  return (
    <div className="rounded-xl border border-slate-800/80 bg-[#0f1424] p-4 hover:border-slate-700 transition">
      <div className="flex items-center justify-between">
        <span className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">{label}</span>
        <Icon className={`w-3.5 h-3.5 text-${color}-400`} />
      </div>
      <div className={`text-xl font-bold mono text-${color}-300 mt-2`}>{value}</div>
      <div className="text-[10px] text-slate-500 mt-0.5">{sub}</div>
    </div>
  );
}

function BarRow({ label, value, total, color }: { label: string; value: number; total: number; color: string }) {
  const pct = total > 0 ? (value / total) * 100 : 0;
  return (
    <div>
      <div className="flex items-center justify-between text-[11px] mb-1">
        <span className="text-slate-300">{label}</span>
        <span className="font-mono text-slate-400">{fmtWh(value, 1)} <span className="text-slate-500">({pct.toFixed(0)}%)</span></span>
      </div>
      <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
        <div className={`h-full bg-gradient-to-r ${color} rounded-full transition-all`} style={{ width: `${Math.min(100, pct)}%` }} />
      </div>
    </div>
  );
}

function Insight({ ok, text, sub }: { ok: boolean; text: string; sub: string }) {
  return (
    <div className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-900/40 border border-slate-800/50">
      {ok ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" /> : <AlertTriangle className="w-3.5 h-3.5 text-amber-400 mt-0.5 shrink-0" />}
      <div className="min-w-0">
        <div className="text-xs text-slate-200 leading-snug">{text}</div>
        <div className="text-[10px] text-slate-500 mt-0.5">{sub}</div>
      </div>
    </div>
  );
}

function StageCard({ num, title, value, sub }: { num: string; title: string; value: string; sub: string }) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-slate-800/80 bg-gradient-to-br from-[#131a2e] to-[#0f1424] p-4">
      <div className="absolute right-2 top-2 text-5xl font-black text-slate-800/40 mono leading-none">{num}</div>
      <div className="text-[10px] uppercase tracking-wider text-orange-400 font-semibold">Stage {num}</div>
      <div className="text-sm font-semibold text-white mt-1">{title}</div>
      <div className="text-2xl font-bold mono text-amber-300 mt-2">{value}</div>
      <div className="text-[10px] text-slate-500 mt-0.5">{sub}</div>
    </div>
  );
}
