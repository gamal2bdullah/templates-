import { LayoutDashboard, ListChecks, Table2, BarChart3, FileText, Library, Settings as SettingsIcon, Zap, ChevronLeft, ChevronRight, BookOpen, ShieldCheck, GitBranch, TestTube, FileCode } from 'lucide-react';
import type { ViewKey } from '../App';

interface SidebarProps {
  view: ViewKey;
  setView: (v: ViewKey) => void;
  open: boolean;
  setOpen: (b: boolean | ((p: boolean) => boolean)) => void;
}

const NAV_ITEMS: { key: ViewKey; label: string; icon: any; desc: string }[] = [
  { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, desc: 'Overview & KPIs' },
  { key: 'inventory', label: 'Load Inventory', icon: ListChecks, desc: 'Manage all loads' },
  { key: 'schedule', label: 'Master Schedule', icon: Table2, desc: 'Engineering load schedule' },
  { key: 'analysis', label: 'Analysis Engine', icon: BarChart3, desc: 'Profiles, peaks, demand' },
  { key: 'phase', label: 'Phase Balancer', icon: GitBranch, desc: '3-phase optimization' },
  { key: 'validation', label: 'Validation Matrix', icon: ShieldCheck, desc: '5-severity rules' },
  { key: 'assumptions', label: 'Assumptions', icon: BookOpen, desc: 'Policy registry' },
  { key: 'reports', label: 'Engineering Reports', icon: FileText, desc: 'Technical summaries' },
  { key: 'library', label: 'Appliance Library', icon: Library, desc: 'Reference database' },
  { key: 'tests', label: 'Test Suite', icon: TestTube, desc: 'Self-audit engine' },
  { key: 'docs', label: 'Documentation', icon: FileCode, desc: 'Architecture & formulas' },
  { key: 'settings', label: 'Project Settings', icon: SettingsIcon, desc: 'Project configuration' },
];

export function Sidebar({ view, setView, open, setOpen }: SidebarProps) {
  return (
    <aside className={`${open ? 'w-64' : 'w-16'} transition-all duration-300 shrink-0 border-r border-slate-800/80 bg-[#0f1424] flex flex-col`}>
      {/* Brand */}
      <div className="h-16 flex items-center gap-3 px-4 border-b border-slate-800/80">
        <div className="relative shrink-0">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-orange-500 to-amber-400 flex items-center justify-center shadow-lg shadow-orange-500/30">
            <Zap className="w-5 h-5 text-white" strokeWidth={2.5} />
          </div>
          <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#0f1424]" />
        </div>
        {open && (
          <div className="overflow-hidden">
            <div className="text-sm font-bold text-white tracking-tight whitespace-nowrap">ITEL SOLAR</div>
            <div className="text-[10px] text-slate-400 font-medium whitespace-nowrap">Load Calculator v3.0</div>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
        {NAV_ITEMS.map(item => {
          const Icon = item.icon;
          const active = view === item.key;
          return (
            <button
              key={item.key}
              onClick={() => setView(item.key)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all relative group ${
                active
                  ? 'bg-gradient-to-r from-orange-500/20 to-amber-500/10 text-orange-300 border border-orange-500/30'
                  : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
              }`}
            >
              {active && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-gradient-to-b from-orange-500 to-amber-400 rounded-r-full" />}
              <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-orange-400' : ''}`} />
              {open && (
                <div className="flex-1 text-left overflow-hidden">
                  <div className="text-sm font-medium whitespace-nowrap">{item.label}</div>
                  <div className="text-[10px] text-slate-500 whitespace-nowrap">{item.desc}</div>
                </div>
              )}
              {!open && (
                <div className="absolute left-full ml-2 px-2 py-1 bg-slate-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 border border-slate-700">
                  {item.label}
                </div>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer / collapse */}
      <div className="p-2 border-t border-slate-800/80">
        <button
          onClick={() => setOpen(o => !o)}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-slate-400 hover:bg-slate-800/40 hover:text-slate-200 transition"
        >
          {open ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          {open && <span className="text-xs font-medium">Collapse</span>}
        </button>
        {open && (
          <div className="mt-2 px-3 py-2 text-[10px] text-slate-500 leading-relaxed">
            Engineering-grade load analysis for solar PV system design.
          </div>
        )}
      </div>
    </aside>
  );
}
